package com.example.exercise2_ctapdevl;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText usernameEditText;
    EditText passwordEditText;
    Button loginButton;

    // Hardcoded username and password
    private static final String HARD_CODED_USERNAME = "alliyah";
    private static final String HARD_CODED_PASSWORD = "pass123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.button);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the entered username and password
                String enteredUsername = usernameEditText.getText().toString();
                String enteredPassword = passwordEditText.getText().toString();

                // Check if the entered username and password match the hardcoded values
                if (enteredUsername.equals(HARD_CODED_USERNAME) && enteredPassword.equals(HARD_CODED_PASSWORD)) {
                    // If username and password are correct, go to the next activity
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    intent.putExtra("username", enteredUsername);
                    startActivity(intent);
                } else {
                    // If username and password are incorrect, show a toast message
                    Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}